transport_gapstudy
==================

A transportation engineering project : Simulation in Java which analyses the traffic flow at an uncontrolled intersection
