import java.io.*;

public class RoadAlgo {
	
}