publicclassGap_Study{
	/*this prints hi jeffy*/

	publicstaticvoidmain(String[] args){
	System.out.println("Hi Jeffy");
	}
}


