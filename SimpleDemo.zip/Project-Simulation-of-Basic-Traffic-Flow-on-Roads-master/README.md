# CME 2101 Assignment Simulation-of-Basic-Traffic-Flow-on-Roads
Hello Everyone this was an assignment prepared for Dokuz Eylul University Computer Engineering CME-2101 Project Based Learning Class.


All of the details that wanted from us can be found at Homework.pdf file.

Please enjoy rewieving my code and feel free to copy , contribute and do whatever you want ! 
