function [road,v,vmax]=move_forward(road,v,vmax,probslow,merge)
    global all_num;
    [L,W]=size(road);%������С�������߽�
    for lanes=2:3;
         temp=find(road(:,lanes)>=1);
         nn=length(temp);
         for k=1:nn
             i=temp(k);
             if(lanes == 2)
                 front = find(road(i+1:merge,lanes)>0,1);
                 if(i+v(i,lanes)>=merge | (~isempty(front)&(i+v(i,lanes)>=front))) 
                    if(i+v(i,lanes)>=merge) 
                        if(merge-i>1)
                            %�����߽����1��
                            v(i+1,lanes) = 1;
                            road(i+1,lanes) = road(i,lanes);
                            road(i,lanes) = 0;
                            v(i,lanes) = 0;
                            vmax(i+1,lanes) = vmax(i,lanes);
                            vmax(i,lanes) = 0;
                        elseif(merge-i==1)
                            %�����߽����1��
                            v(i+1,lanes) = 0;
                            road(i+1,lanes) = road(i,lanes);
                            road(i,lanes) = 0;
                            v(i,lanes) = 0;
                            vmax(i+v(front,lanes),lanes) = vmax(i,lanes);
                            vmax(i,lanes) = 0;
                        elseif(merge==i)
                            v(i,lanes) = 0;
                        end
                    elseif(v(front,lanes)~=0)
                        %���ǰ���г������ٶȲ�Ϊ0
                        num = min(i+v(front,lanes),max(front-1,1));
                        road(num,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        v(i,lanes) = 0;
                        v(num,1) = v(front,lanes);
                        vmax(num,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    else
                        %���ǰ��ĳ��ٶ�Ϊ0���������1�����ٶȱ�Ϊ1�������ٶȱ�Ϊ0
                        if(front-i>1)
                            v(i+1,lanes) = 1;
                            road(i+1,lanes) = road(i,lanes);
                            road(i,lanes) = 0;
                            v(i,lanes) = 0;
                            vmax(i+1,lanes) = vmax(i,lanes);
                            vmax(i,lanes) = 0;
                        elseif(front-i==1)
                            v(i,lanes) = 0;
                            
                        end
                    end
                 elseif(road(i,lanes)==1&&rand<probslow)
                    a_v = v(i,lanes);
                    num = min(i+v(front,lanes),max(front-1,1));
                    v(i+a_v,lanes) = max(v(i,lanes)-1,1);             %�������
                    v(i,lanes) = 0;
                    road(i+a_v,lanes) = road(i,lanes);
                    road(i,lanes) = 0;
                    vmax(i+a_v,lanes) = vmax(i,lanes);
                    vmax(i,lanes) = 0;
                 elseif(isempty(front) | front-i>v(i,lanes)+1)                         %���ڲ��ܽ��м���
                    a_v = v(i,lanes);
                    v(i+a_v,lanes) = min(v(i,lanes)+1,vmax(i,lanes)); %����
                    v(i,lanes) = 0;
                    road(i+a_v,lanes) = road(i,lanes);
                    road(i,lanes) = 0;
                    vmax(i+a_v,lanes) = vmax(i,lanes);
                    vmax(i,lanes) = 0;
                 elseif(front-i<=v(i,lanes))                        %С�ڰ�ȫ������м��٣�����Ϊǰ���ٶ�
                    a_v = v(i,lanes);
                    v(i+a_v,lanes) = max(v(front,lanes),1);             %����
                    v(i,lanes) = 0;
                    road(i+a_v,lanes) = road(i,lanes);
                    road(i,lanes) = 0;
                    vmax(i+a_v,lanes) = vmax(i,lanes);
                    vmax(i,lanes) = 0;
                 end
            elseif(lanes==3)
                 front = find(road(i+1:end,lanes)>0,1)+i;
                 a = find(road(:,lanes)~=0);
                 c = road(a,lanes);
                 if(isempty(front)&i+v(i,lanes)>=L)
                     v(i,lanes) = 0;
                     vmax(i,lanes) = 0;
                     road(i,lanes) = 0;
                     all_num = all_num+1;
                 elseif(front-i==1)
                     v(i,lanes) = min(v(front,lanes),vmax(i,lanes));
                 elseif((isempty(front) | front-1>=v(i,lanes)+i) & road(i,lanes)==1 & rand<probslow)
                    a_v = v(i,lanes);
                    if(road(i+a_v,lanes)==0)
                        v(i+a_v,lanes) = max(v(i,lanes)-1,1);             %�������
                        v(i,lanes) = 0;
                        road(i+a_v,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        vmax(i+a_v,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    elseif(road(i+a_v,lanes)~=0)
                        v(front-1,lanes) = 1;                     %�������
                        v(i,lanes) = 0;
                        road(front-1,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        vmax(front,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    end
                 elseif(isempty(front) | front-1>=v(i,lanes)+i& front > i+1)                         %���ڲ��ܽ��м���
                    a_v = v(i,lanes);
                    if(road(i+a_v,lanes)==0)
                        v(i+a_v,lanes) = min(v(i,lanes)+1,vmax(i,lanes)); %����
                        v(i,lanes) = 0;
                        road(i+a_v,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        vmax(i+a_v,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    elseif(a_v~=0)
                        v(front-1,lanes) = min(v(i,lanes)+1,vmax(i,lanes)); %����
                        v(i,lanes) = 0;
                        road(front,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        vmax(front,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    else
                        v(i,lanes) = 1;
                    end
                 elseif(~isempty(front) & i+v(i,lanes)> front & front > i+1)
                    num = min(i+v(front,lanes),max(front-1,1));
                    if(num~=i)
                        road(num,lanes) = road(i,lanes);
                        road(i,lanes) = 0;
                        v(num,1) = v(i,lanes);
                        v(i,lanes) = 0;
                        vmax(num,lanes) = vmax(i,lanes);
                        vmax(i,lanes) = 0;
                    end
                 end
                 b = find(road(:,lanes)~=0);
             end
         end
    end
end

