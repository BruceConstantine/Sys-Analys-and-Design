function h = show_road(road,h,n)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [L,W]=size(road); 
    temp=road;
    temp(temp==1)=0;%create the palza without any cars

    road_draw=road;  

    ROAD(:,:,1)=road_draw;
    ROAD(:,:,2)=road_draw;
    ROAD(:,:,3)=temp;
    ROAD=1-ROAD;
    ROAD(ROAD>1)=ROAD(ROAD>1)/6;
    

    if ishandle(h)
    set(h,'CData',ROAD);
    pause(n);
    else
    colorbar;
    set(h,'CData',ROAD);
    plot([(0:W)',(0:W)']+0.5,[0,L]+0.5,'k');
    plot([0,W]+0.5,[(0:L)',(0:L)']+0.5,'k');
    axis image
    set(h, 'xtick', [], 'ytick', []);
    pause(n);
    end
end

