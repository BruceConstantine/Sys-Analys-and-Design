clc;
close all;
%=====================GUI����========================================
plotbutton=uicontrol('style','pushbutton',...
   'string','Run', ...
   'fontsize',12, ...
   'position',[100,400,50,20], ...
   'callback', 'run=1;');

%define the stop button
erasebutton=uicontrol('style','pushbutton',...
   'string','Stop', ...
   'fontsize',12, ...
   'position',[200,400,50,20], ...
   'callback','freeze=1;');

%define the Quit button
quitbutton=uicontrol('style','pushbutton',...
   'string','Quit', ...
   'fontsize',12, ...
   'position',[300,400,50,20], ...
   'callback','stop=1;close;');

number = uicontrol('style','text', ...
    'string','1', ...
   'fontsize',12, ...
   'position',[20,400,50,20]);
%=======================��ʼ��������======================================
B=2;             %The number of the lanes
roadlength=50;  %The length of the simulating highways
merge = 30;
barrier = 10;
scale = 0;
switch_ratio = 0.8;

road=zeros(roadlength,B+2);
v=zeros(roadlength,B+2);

road(merge+1:roadlength,2) = -1;  
road(1:roadlength,[1,B+2])=-1;

h = imagesc(road);
set(h, 'erasemode', 'none')
axis equal
axis tight
vmax = zeros(50,4);
probc=0.3;          % �������ܶ�
probv=[0.5,0.5];      % ���ֳ������ܶȷֲ�
probslow=0.1;       % ��������ĸ���
VTypes=[2,3];     % ��·��һ���м�������ٶȲ�ͬ�ĳ���,�ٶ���ʲô
[road,v,vmax]=new_cars(road,v,probc,probv,VTypes,vmax,scale);%һ��ʼ���ڳ����ϲ��ó�����������ѭ����ʻ��Ҳ����۲������ܶ�֮��Ĺ�ϵ
ROAD=rot90(road,2);
h=show_road(ROAD,h,0.1);
%======================���е���========================================
global all_num; 
all_num = 0;
all_note = zeros(11,1);
run = 1;
stop = 0;
freeze = 0;
probc = 0.3;
for i = 1:5
    while(stop<1000)
        if (run==1)
            [v,LUP,LDOWN]=road_count(road,v);
            [road,v,vmax]=switch_lane(road,v,vmax,LUP,LDOWN,barrier,switch_ratio);
            [road,v,vmax]=move_forward(road,v,vmax,probslow,merge);
            [road,v,vmax]=new_cars(road,v,probc,probv,VTypes,vmax,scale);
            ROAD=rot90(road,2);
            h=show_road(ROAD,h,0.1);
        end
        if (freeze==1)
            run = 0;
            freeze = 0;
        end
        drawnow
        stop = stop+1;
    end
    stop = 0;
    road=zeros(roadlength,B+2);
    probc = probc + 0.1;
    v=zeros(roadlength,B+2);
 %   scale = scale + 0.1;
    road(merge:roadlength,2) = -1;  
    road(1:roadlength,[1,B+2])=-1;
    all_note(i,1) = all_num;
    all_num = 0;
end