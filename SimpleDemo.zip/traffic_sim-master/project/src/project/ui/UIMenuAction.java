package project.ui;

public abstract interface UIMenuAction {
  public abstract void run();
}