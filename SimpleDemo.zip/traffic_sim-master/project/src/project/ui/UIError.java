package project.ui;

public class UIError extends Error {
  private static final long serialVersionUID = 2008L;
}