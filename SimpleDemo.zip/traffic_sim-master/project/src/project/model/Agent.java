package project.model;

/**
 * Interface for active model objects.
 */
public interface Agent {
  public abstract void run(double paramDouble);
}