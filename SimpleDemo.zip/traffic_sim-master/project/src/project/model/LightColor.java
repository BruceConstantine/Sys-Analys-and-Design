package project.model;

public enum LightColor {
	RED, YELLOW, GREEN;
}