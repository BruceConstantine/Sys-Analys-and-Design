# vehicle-analytics
core modules and classes for analyzing vehicle, ADAS or ITS impacts on traffic flow via simulation or data analytics
