package com.briup.LISTENER;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class actionListener4 implements ActionListener {

	public actionListener4() {
		
	}

	public void actionPerformed(ActionEvent evt) {
		JOptionPane.showMessageDialog(null, "04级计算机041班 元俊 33号", "作者",
				JOptionPane.INFORMATION_MESSAGE);

	}

}
