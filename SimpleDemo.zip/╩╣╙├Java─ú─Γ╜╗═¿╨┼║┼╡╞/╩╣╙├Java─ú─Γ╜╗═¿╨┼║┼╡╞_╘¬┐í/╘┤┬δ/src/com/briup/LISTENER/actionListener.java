package com.briup.LISTENER;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import com.briup.GUI.ImageFrame;
public class actionListener implements ActionListener {
	public actionListener() {
		
	}

	public void actionPerformed(ActionEvent evt) {
		ImageFrame.startitem.setEnabled(false);
		ImageFrame.stopitem.setEnabled(true);
		ImageFrame.ew.resume();
		ImageFrame.ns.resume();

	}

}
