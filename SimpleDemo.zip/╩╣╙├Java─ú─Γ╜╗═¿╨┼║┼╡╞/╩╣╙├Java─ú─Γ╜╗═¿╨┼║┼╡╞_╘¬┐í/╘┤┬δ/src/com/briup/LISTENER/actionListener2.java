package com.briup.LISTENER;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import com.briup.GUI.ImageFrame;


public class actionListener2 implements ActionListener {

	
	public actionListener2() {
	
	}

	public void actionPerformed(ActionEvent evt) {
		ImageFrame.startitem.setEnabled(true);
		ImageFrame.stopitem.setEnabled(false);
		ImageFrame.ew.suspend();
		ImageFrame.ns.suspend();

	}

}
