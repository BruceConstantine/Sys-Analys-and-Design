package com.briup.LISTENER;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.briup.Exception.TrafficLightError;
import com.briup.GUI.roadpanel;

public class keyListener implements KeyListener {

	private int num = 0, r;

	private String np = "";

	public keyListener() {

	}

	public void keyPressed(KeyEvent e) {

	}

	public void keyReleased(KeyEvent evt) {
		int keyCode = evt.getKeyCode();
		if (keyCode == KeyEvent.VK_ENTER) {
			try{
				if(!roadpanel.liu.getText().matches("\\d{1,8}")){
					JOptionPane.showMessageDialog(null, "你没有输入一个数字,或则输入的数字超过8位!!!","输入错误!!!", JOptionPane.ERROR_MESSAGE);
					num=0;
					//roadpanel.liu.setText("");
					return;
				}
				
				num = Integer.parseInt(roadpanel.liu.getText());
				
				if(num>=0){
					num=num/60;
				}else if(num<0){
					num=-1;
					JOptionPane.showMessageDialog(null, "请输入正数!!!","输入错误!!!", JOptionPane.ERROR_MESSAGE);							
					num = 0;
					roadpanel.liu.setText("");
				}


				if(num>=0){
					if((num>0)&&(num<=15)){
						num=15;
					}else if(num==0){
						num=10;
					}else if((num>15)&&(num<=50)){
						num=30;
					}else{
						num=50;
					}			
				}
				r = JOptionPane.showConfirmDialog(null, "下次执行的时间为"+ num + "秒", "是否确定???",JOptionPane.YES_NO_OPTION);	
					num = 0;
					roadpanel.liu.setText("");	
				}catch(NumberFormatException e){
					TrafficLightError.outNum(e);
				}catch(Exception e){
					TrafficLightError.out(e);
				}
				roadpanel.time.setText(np.valueOf(num));
		}

	}

	public void keyTyped(KeyEvent e) {

	}

}
