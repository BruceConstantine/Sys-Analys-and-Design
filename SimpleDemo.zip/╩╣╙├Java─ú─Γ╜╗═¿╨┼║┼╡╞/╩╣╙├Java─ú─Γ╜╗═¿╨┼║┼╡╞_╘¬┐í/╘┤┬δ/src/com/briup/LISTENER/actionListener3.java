package com.briup.LISTENER;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.briup.GUI.ImageFrame;

public class actionListener3 implements ActionListener {

	private Thread ns,ew;
	public actionListener3() {
	
	}

	public void actionPerformed(ActionEvent evt) {
		ImageFrame.ns.stop();
		ImageFrame.ew.stop();
		System.exit(0);

	}

}
