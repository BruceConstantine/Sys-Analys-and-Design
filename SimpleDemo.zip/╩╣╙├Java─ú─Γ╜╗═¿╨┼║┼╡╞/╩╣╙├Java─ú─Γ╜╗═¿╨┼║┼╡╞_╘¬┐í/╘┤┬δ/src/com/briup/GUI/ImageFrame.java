package com.briup.GUI;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import com.briup.LISTENER.actionListener;
import com.briup.LISTENER.actionListener2;
import com.briup.LISTENER.actionListener3;
import com.briup.LISTENER.actionListener4;
import com.briup.LISTENER.windowAdapter;

public class ImageFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3627977954101077299L;

	JMenuBar menubar;

	JMenu editMenu, ed;

	public static JMenuItem startitem, stopitem, exititem, editem;
	public static Thread ns;
	public static Thread ew;

	public ImageFrame(Thread ns, Thread ew) {		
		super("Control Trafficlight!");
		this.ns=ns;
		this.ew=ew;
		setSize(808, 659);
		
		addWindowListener(new windowAdapter());
		
		menubar = new JMenuBar();
		setJMenuBar(menubar);
		editMenu = new JMenu("操作(O)");
		ed = new JMenu("作者(M)");
		startitem = new JMenuItem("继续(C)", 'C');
		stopitem = new JMenuItem("暂停(S)", 'S');
		exititem = new JMenuItem("退出(Q)", 'Q');
		editem = new JMenuItem("作者(M)", 'M');
		menubar.add(editMenu);
		menubar.add(ed);
		editMenu.add(startitem);
		editMenu.add(stopitem);
		editMenu.addSeparator();
		editMenu.add(exititem);
		ed.add(editem);
		editMenu.setMnemonic('O');
		ed.setMnemonic('M');
		startitem.setMnemonic('C');
		stopitem.setMnemonic('S');
		exititem.setMnemonic('Q');
		editem.setMnemonic('M');
		startitem.setEnabled(false);
		
		startitem.addActionListener(new actionListener());
		
		stopitem.addActionListener(new actionListener2());
		
		exititem.addActionListener(new actionListener3());
		
		editem.addActionListener(new actionListener4());
		
		
	}
}
