package com.briup.GUI;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Date;
import com.briup.LISTENER.keyListener;

public class roadpanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1568989296186999581L;
	
	public Image image;

	public JLabel n1, n2, n3, e1, e2, e3, s1, s2, s3, w1, w2, w3, l, per, d;

	public Font f1, f2, f3, f4;

	public JPanel pn, pe, ps, pw;

	public JTextField n, e, s, w;

	public static JTextField liu;

	public static JTextField time;

	
	public roadpanel() {
		image = Toolkit.getDefaultToolkit().getImage("image.jpg");
		MediaTracker tracker = new MediaTracker(this);
		tracker.addImage(image, 0);
		try {
			tracker.waitForID(0);
		} catch (InterruptedException e) {
		}
		setLayout(null);
		f1 = new Font("ScansSerif", Font.BOLD, 40);
		f2 = new Font("ScansSerif", Font.BOLD, 35);
		f3 = new Font("ScansSerif", Font.BOLD, 25);
		f4 = new Font("ScansSerif", Font.BOLD, 15);
		pn = new JPanel();
		pe = new JPanel();
		ps = new JPanel();
		pw = new JPanel();
		n = new JTextField("00", 10);
		e = new JTextField("00", 10);
		s = new JTextField("00", 10);
		w = new JTextField("00", 10);
		liu = new JTextField("", 3);
		time = new JTextField("0", 3);
		n1 = new JLabel("←", SwingConstants.CENTER);
		n2 = new JLabel("↓", SwingConstants.CENTER);
		n3 = new JLabel("→", SwingConstants.CENTER);
		e1 = new JLabel("↑", SwingConstants.CENTER);
		e2 = new JLabel("←", SwingConstants.CENTER);
		e3 = new JLabel("↓", SwingConstants.CENTER);
		s1 = new JLabel("←", SwingConstants.CENTER);
		s2 = new JLabel("↑", SwingConstants.CENTER);
		s3 = new JLabel("→", SwingConstants.CENTER);
		w1 = new JLabel("↑", SwingConstants.CENTER);
		w2 = new JLabel("→", SwingConstants.CENTER);
		w3 = new JLabel("↓", SwingConstants.CENTER);
		l = new JLabel("流量控制", SwingConstants.CENTER);
		per = new JLabel("辆/小时", SwingConstants.CENTER);
		d = new JLabel("日期时间", SwingConstants.CENTER);
		add(pn);
		add(pe);
		add(ps);
		add(pw);
		add(l);
		add(per);
		add(liu);
		add(time);
		add(d);
		l.setBounds(10, 50, 120, 30);
		liu.setBounds(130, 50, 100, 30);
		per.setBounds(230, 50, 120, 30);
		time.setBounds(100, 100, 100, 30);
		d.setBounds(530, 550, 300, 20);
		time.setVisible(false);
		l.setFont(f3);
		liu.setFont(f3);
		d.setFont(f4);
		
		liu.addKeyListener(new keyListener());
		
		per.setFont(f3);
		pn.setBounds(290, 155, 184, 45);
		pn.setLayout(new GridLayout(1, 4, 1, 0));
		pn.setBackground(Color.darkGray);
		pe.setBounds(520, 216, 40, 164);
		pe.setLayout(new GridLayout(4, 1, 0, 1));
		pe.setBackground(Color.darkGray);
		ps.setBounds(321, 398, 184, 45);
		ps.setLayout(new GridLayout(1, 4, 1, 0));
		ps.setBackground(Color.darkGray);
		pw.setBounds(239, 223, 40, 164);
		pw.setLayout(new GridLayout(4, 1, 0, 1));
		pw.setBackground(Color.darkGray);
		pn.add(n1);
		pn.add(n2);
		pn.add(n3);
		pn.add(n);
		pe.add(e1);
		pe.add(e2);
		pe.add(e3);
		pe.add(e);
		ps.add(s);
		ps.add(s1);
		ps.add(s2);
		ps.add(s3);
		pw.add(w);
		pw.add(w1);
		pw.add(w2);
		pw.add(w3);
		n1.setFont(f1);
		n1.setForeground(Color.darkGray);
		n2.setFont(f1);
		n2.setForeground(Color.darkGray);
		n3.setFont(f1);
		n3.setForeground(Color.darkGray);
		e1.setFont(f2);
		e1.setForeground(Color.darkGray);
		e2.setFont(f2);
		e2.setForeground(Color.darkGray);
		e3.setFont(f2);
		e3.setForeground(Color.darkGray);
		s1.setFont(f1);
		s1.setForeground(Color.darkGray);
		s2.setFont(f1);
		s2.setForeground(Color.darkGray);
		s3.setFont(f1);
		s3.setForeground(Color.darkGray);
		w1.setFont(f2);
		w1.setForeground(Color.darkGray);
		w2.setFont(f2);
		w2.setForeground(Color.darkGray);
		w3.setFont(f2);
		w3.setForeground(Color.darkGray);
		n.setFont(f1);
		n.setEditable(false);
		n.setForeground(Color.red);
		n.setBackground(Color.cyan);
		e.setFont(f2);
		e.setEditable(false);
		e.setForeground(Color.red);
		e.setBackground(Color.cyan);
		s.setFont(f1);
		s.setEditable(false);
		s.setForeground(Color.red);
		s.setBackground(Color.cyan);
		w.setFont(f2);
		w.setEditable(false);
		w.setForeground(Color.red);
		w.setBackground(Color.cyan);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(image, 0, 0, this);
	}
}
