package com.briup.TEST;

import javax.swing.JFrame;

import com.briup.GUI.ImageFrame;
import com.briup.GUI.roadpanel;
import com.briup.ThreadControl.Controlew;
import com.briup.ThreadControl.Controlns;

public class TrafficLightTest {

	
	public static void main(String[] args) {
		roadpanel rp = new roadpanel();
		Controlew cew = new Controlew(rp);
		Controlns cns = new Controlns(rp, cew);
		final Thread ns = new Thread(cns);
		final Thread ew = new Thread(cew);
		JFrame frame = new ImageFrame(ns, ew);
		frame.add(rp);
		frame.setVisible(true);
		ns.start();
		ew.start();

	}

}
