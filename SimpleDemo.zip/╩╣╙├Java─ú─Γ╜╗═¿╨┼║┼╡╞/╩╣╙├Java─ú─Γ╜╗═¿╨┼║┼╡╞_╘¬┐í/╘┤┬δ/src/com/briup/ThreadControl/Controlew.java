package com.briup.ThreadControl;

import java.awt.Color;
import java.util.Date;

import com.briup.Exception.TrafficLightError;
import com.briup.GUI.roadpanel;

public class Controlew implements Runnable {

	private int i = 0, p, n, e, tp = 0;

	private String s = "", w = "", t = "";

	private roadpanel rpanel;

	Date date;

	boolean v = true;

	public Controlew(roadpanel rp) {
		rpanel = rp;
	}

	public void run() {
		out: while (true) {
			synchronized (this) {
				if (!v) {
					try {
						this.wait();
					} catch (Exception e) {
						TrafficLightError.out(e);
					}
				}
				rpanel.n1.setForeground(Color.green);
				rpanel.n2.setForeground(Color.red);
				rpanel.n3.setForeground(Color.red);
				rpanel.n.setForeground(Color.red);
				rpanel.e1.setForeground(Color.green);
				rpanel.e2.setForeground(Color.green);
				rpanel.e3.setForeground(Color.green);
				rpanel.e.setForeground(Color.green);
				rpanel.s1.setForeground(Color.red);
				rpanel.s2.setForeground(Color.red);
				rpanel.s3.setForeground(Color.green);
				rpanel.s.setForeground(Color.red);
				rpanel.w1.setForeground(Color.green);
				rpanel.w2.setForeground(Color.green);
				rpanel.w3.setForeground(Color.green);
				rpanel.w.setForeground(Color.green);
				tp = Integer.parseInt(rpanel.time.getText());
				if (tp != 0) {
					n = tp + 1;
				} else {
					n = 11;
				}
				t.indexOf(n);
				rpanel.n.setText(t);
				rpanel.s.setText(t);
				rpanel.e.setText(t);
				rpanel.w.setText(t);
				while (true) {
					date = new Date();
					rpanel.d.setText(date.toString());
					try {
						Thread.currentThread().sleep(1000);
					} catch (Exception e) {
						TrafficLightError.out(e);
					}
					if (n == 4) {
						rpanel.e2.setForeground(Color.yellow);
						rpanel.e.setForeground(Color.yellow);
						rpanel.e3.setForeground(Color.yellow);
						rpanel.w2.setForeground(Color.yellow);
						rpanel.w.setForeground(Color.yellow);
						rpanel.w1.setForeground(Color.yellow);
					} else if (n == 1)
						break;
					n--;
					if (n < 10)
						s = "0" + s.valueOf(n);
					else
						s = s.valueOf(n);
					rpanel.n.setText(s);
					rpanel.s.setText(s);
					rpanel.e.setText(s);
					rpanel.w.setText(s);
				}
				v = false;
				this.notify();

			}
		}
	}

}
