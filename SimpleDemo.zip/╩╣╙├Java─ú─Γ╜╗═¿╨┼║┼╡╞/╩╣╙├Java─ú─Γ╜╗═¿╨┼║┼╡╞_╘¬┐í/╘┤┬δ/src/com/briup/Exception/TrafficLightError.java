package com.briup.Exception;


public class TrafficLightError {
	
	public static void out(Exception e){
		if (e==null)return;
		e.printStackTrace();
		System.out.println("error code: "+e. getStackTrace());
	}	
	
	public static void outNum(NumberFormatException e){
		if (e==null)return;
		e.printStackTrace();
		System.out.println("error code: "+e. getStackTrace());
	}
}
