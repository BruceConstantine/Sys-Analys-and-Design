package com.briup.MAIN;

public class TrafficLight {

	
	public TrafficLight() {
		
	}

	
}
